
# Medication Information

## Paracetamol
**Uses:**  
- Fever  
- Mild pain relief  

**Dosage:**  
- 500-1000mg every 4-6 hours  
- Maximum 4000mg per day  

**Side Effects:**  
- Nausea  
- Rash  
- Liver damage (if overdosed)  

---

## Ibuprofen
**Uses:**  
- Pain relief  
- Anti-inflammatory  

**Dosage:**  
- 200-400mg every 4-6 hours  
- Maximum 3200mg per day  

**Side Effects:**  
- Stomach upset  
- Heartburn  
- Increased risk of heart attack (if used long-term)  

---

## Amoxicillin
**Uses:**  
- Bacterial infections such as pneumonia, ear infections, throat infections  

**Dosage:**  
- 250-500mg every 8 hours for 7-10 days  

**Side Effects:**  
- Nausea  
- Diarrhea  
- Allergic reactions (rash, itching)  

---

## Aspirin
**Uses:**  
- Pain relief  
- Anti-inflammatory  
- Blood thinning  

**Dosage:**  
- 81mg daily for blood thinning  
- Up to 4000mg for pain relief  

**Side Effects:**  
- Stomach upset  
- Bleeding risk  
- Tinnitus (ringing in ears)  

---

## Metformin
**Uses:**  
- Type 2 Diabetes management  
- Improves blood sugar control  

**Dosage:**  
- 500-1000mg twice daily with meals  
- Up to 2000-2500mg per day  

**Side Effects:**  
- Nausea  
- Bloating  
- Lactic acidosis (rare but serious)  

---

## Lisinopril
**Uses:**  
- High blood pressure  
- Heart failure  
- Chronic kidney disease  

**Dosage:**  
- 10-40mg once daily, depending on condition  

**Side Effects:**  
- Dizziness  
- Dry cough  
- Increased potassium levels  

---

## Azithromycin
**Uses:**  
- Antibiotic for infections like respiratory infections, skin infections  

**Dosage:**  
- 500mg on the first day, followed by 250mg for 4 days  

**Side Effects:**  
- Diarrhea  
- Nausea  
- QT prolongation (irregular heartbeat)  

---

## Prednisone
**Uses:**  
- Inflammation  
- Autoimmune disorders  
- Allergies  

**Dosage:**  
- 5-60mg daily depending on the condition  

**Side Effects:**  
- Weight gain  
- Mood changes  
- Increased blood sugar  

---

## Albuterol
**Uses:**  
- Bronchodilator for asthma or chronic obstructive pulmonary disease (COPD)  

**Dosage:**  
- 2 inhalations every 4-6 hours as needed for shortness of breath  

**Side Effects:**  
- Increased heart rate  
- Tremors  
- Nervousness  

---

## Levothyroxine
**Uses:**  
- Hypothyroidism (underactive thyroid)  

**Dosage:**  
- 25-200 mcg once daily before breakfast  

**Side Effects:**  
- Weight changes  
- Hair thinning  
- Insomnia  

---

## Atorvastatin
**Uses:**  
- High cholesterol  
- Reduces risk of heart disease  

**Dosage:**  
- 10-80 mg once daily  

**Side Effects:**  
- Muscle pain  
- Liver enzyme elevation  
- Digestive issues  

---

## Omeprazole
**Uses:**  
- Acid reflux  
- Gastric ulcers  

**Dosage:**  
- 20-40mg once daily before meals  

**Side Effects:**  
- Headache  
- Nausea  
- Vitamin B12 deficiency (if used long-term)  

---

## Warfarin
**Uses:**  
- Blood thinning  
- Prevention of blood clots  

**Dosage:**  
- 2-10mg once daily, depending on INR level  

**Side Effects:**  
- Bleeding risk  
- Bruising  
- Skin necrosis (rare)  

---

## Cetirizine
**Uses:**  
- Allergy relief (hay fever, hives)  

**Dosage:**  
- 5-10mg once daily  

**Side Effects:**  
- Drowsiness  
- Dry mouth  
- Headache  

---

## Furosemide
**Uses:**  
- Edema (fluid retention)  
- High blood pressure  

**Dosage:**  
- 20-80mg once or twice daily  

**Side Effects:**  
- Dehydration  
- Low potassium levels  
- Increased urination  

---

## Loratadine
**Uses:**  
- Allergy relief (seasonal allergies)  

**Dosage:**  
- 10mg once daily  

**Side Effects:**  
- Dry mouth  
- Drowsiness  
- Headache  
