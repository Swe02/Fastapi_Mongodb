
# Disease and Treatment Information

## Diabetes
**Symptoms:**  
- Increased thirst  
- Frequent urination  
- Extreme hunger  
- Unexplained weight loss  
- Fatigue  
- Blurred vision  
- Slow-healing sores  
- Tingling or numbness in hands and feet  

**Causes:**  
- Insulin resistance  
- Autoimmune destruction of insulin-producing cells  
- Obesity  
- Genetic factors  

**Diagnosis:**  
- Fasting blood sugar test  
- Oral glucose tolerance test  
- Hemoglobin A1c test  

**Treatment:**  
- Insulin therapy  
- Healthy diet  
- Regular exercise  
- Blood sugar monitoring  
- Oral medications (e.g., Metformin)  
- Weight management  

---

## Hypertension
**Symptoms:**  
- Headaches  
- Shortness of breath  
- Dizziness  
- Nosebleeds  
- Chest pain  
- Vision problems  

**Causes:**  
- High salt intake  
- Stress  
- Obesity  
- Genetic factors  
- Chronic kidney disease  

**Diagnosis:**  
- Blood pressure measurement  
- Ambulatory blood pressure monitoring  
- Blood tests  

**Treatment:**  
- Antihypertensive medications  
- Reduced salt intake  
- Regular exercise  
- Weight management  
- Stress reduction  

---

## Asthma
**Symptoms:**  
- Shortness of breath  
- Wheezing  
- Chest tightness  
- Coughing, especially at night or early morning  
- Increased mucus production  

**Causes:**  
- Allergies  
- Respiratory infections  
- Environmental pollutants  
- Exercise  
- Cold air  

**Diagnosis:**  
- Spirometry  
- Peak flow measurement  
- Allergy testing  

**Treatment:**  
- Inhalers (bronchodilators and corticosteroids)  
- Avoiding triggers  
- Allergy medications  
- Leukotriene modifiers  
- Immunotherapy  

---

## Coronary Artery Disease (CAD)
**Symptoms:**  
- Chest pain  
- Shortness of breath  
- Fatigue  
- Dizziness  
- Heart palpitations  
- Nausea  
- Sweating  

**Causes:**  
- Atherosclerosis  
- High cholesterol  
- Smoking  
- Diabetes  
- High blood pressure  

**Diagnosis:**  
- Electrocardiogram (ECG)  
- Stress test  
- Coronary angiography  
- Blood tests  

**Treatment:**  
- Medications (beta-blockers, ACE inhibitors)  
- Lifestyle changes (exercise, diet)  
- Stenting  
- Bypass surgery  
- Statins  

---

## Alzheimer's Disease
**Symptoms:**  
- Memory loss  
- Confusion  
- Difficulty communicating  
- Mood changes  
- Difficulty with daily tasks  
- Disorientation  
- Personality changes  

**Causes:**  
- Amyloid plaque buildup  
- Neurofibrillary tangles  
- Genetic factors  
- Aging  

**Diagnosis:**  
- Cognitive tests  
- Brain imaging (MRI, CT scan)  
- Blood tests  

**Treatment:**  
- Medications (Donepezil, Rivastigmine)  
- Cognitive therapy  
- Support groups  
- Behavioral therapy  
- Environmental modifications  

---

## Stroke
**Symptoms:**  
- Sudden numbness or weakness  
- Confusion  
- Trouble speaking  
- Trouble seeing  
- Dizziness  
- Loss of balance  
- Severe headache  

**Causes:**  
- Blood clot (ischemic stroke)  
- Bleeding in the brain (hemorrhagic stroke)  
- High blood pressure  
- Smoking  
- Atrial fibrillation  

**Diagnosis:**  
- CT scan  
- MRI  
- Blood tests  
- Angiography  

**Treatment:**  
- Emergency medical care  
- Rehabilitation therapy  
- Blood thinners  
- Surgery in some cases  
- Clot-busting medications  

---

## Cancer (Breast)
**Symptoms:**  
- Lump in the breast  
- Changes in breast shape  
- Skin changes  
- Nipple discharge  
- Pain in the breast  
- Swelling in part of the breast  

**Causes:**  
- Genetic mutations (BRCA1, BRCA2)  
- Hormonal factors  
- Lifestyle factors (alcohol, obesity)  
- Radiation exposure  

**Diagnosis:**  
- Mammogram  
- Ultrasound  
- Biopsy  
- MRI  

**Treatment:**  
- Surgery  
- Chemotherapy  
- Radiation therapy  
- Hormone therapy  
- Immunotherapy  
- Targeted therapy  

---
