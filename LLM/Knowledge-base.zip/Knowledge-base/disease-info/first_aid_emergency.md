
# First Aid and Emergency Contacts

## First Aid Basics
### Cuts and Scrapes
- Clean the wound with water and mild soap.
- Apply an antiseptic and bandage.

### Burns
- Cool the burn under running water.
- Apply aloe vera or burn ointment.

### Choking
- Perform the Heimlich maneuver (abdominal thrusts).

### Fainting
- Lay the person down and elevate their legs.

---

## Emergency Contacts
- **Ambulance:** 911  
- **Poison Control:** 1-800-222-1222  
- **Local Hospital:** [Insert hospital contact number]  
